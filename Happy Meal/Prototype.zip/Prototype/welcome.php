<?php
session_start();
include 'header.php'

?>
<div class="container-fluid">
    <div class="row py-4">
        <div class="col-md-12 py-4">
            <center>
                <h4 class="text-success">WELCOME TO HAPPY MEAL A WEBSITE FOR FRESH AND HEALTY MEAL</h4>
            </center>
        </div>
    </div>
</div>

<?php include 'footer.php' ?>