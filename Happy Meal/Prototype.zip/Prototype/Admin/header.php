<!DOCTYPE html>
<html>

<head>
	<title>Prototype</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/styles.css">
	<style>
		body {
			font-family: Calibri !important;
		}

		ul li a {
			color: rgba(160, 85, 146, 1);
		}
	</style>
</head>

<body>
	<div class="container-fluid px-0">
		<div class="row bg-dark py-3">
			<div class="col-md-12 text-white">
				<center>ADMIN PANNEL</center>
			</div>
		</div>

	</div>