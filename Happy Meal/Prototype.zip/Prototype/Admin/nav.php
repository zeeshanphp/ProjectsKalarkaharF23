 <ul class="nav nav-pills flex-column mb-auto">
   <li class="nav-item py-1">
     <a href="manage_users.php" class="nav-link" style="color: white;">
       MANAGE USERS
     </a>
   </li>

   <li class="nav-item py-1">
     <a href="logout.php" class="nav-link" style="color: white;">
       LOGOUT
     </a>
   </li>
 </ul>